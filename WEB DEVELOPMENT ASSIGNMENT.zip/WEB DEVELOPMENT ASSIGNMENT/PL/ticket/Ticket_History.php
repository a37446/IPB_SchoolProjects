<h1 class="page_title"> [TICKET HISTORY PAGE] </h1> 
<?php include("Bought_tickets.php"); ?>
</div>



