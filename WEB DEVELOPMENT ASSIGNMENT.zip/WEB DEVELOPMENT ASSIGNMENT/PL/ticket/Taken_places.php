<div class="page_div">
    Taken Places:
    <?php echo Ticket::occupied_places($_POST['event_name'])?>
</div>


