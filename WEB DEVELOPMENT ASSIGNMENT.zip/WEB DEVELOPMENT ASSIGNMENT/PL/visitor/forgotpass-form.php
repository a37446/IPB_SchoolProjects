        
        <div class="lightbox" id="forgotpass_lightbox">
            <a class="close_button" href="#"> X </a>
            <form class="window_form" action="#" method="POST">
            <h2> Forgot password? </h2>
            <span class="input_description"> Enter your mail address and we will send you instructions on how to reset your password </span> <br/>
            <input type="email" name="email" class="input_text" placeholder="prova@example.com" required> <br/>
            <input id="reset_pass_sub" class="submit_button" type="submit" value="Reset Password" name="respassword_submit"> <br/>
            <a id="link_forgotpass_register" class="lightbox_link" href="#register_lightbox"> Register Account </a> <br/>
            <a id="link_forgotpass_login" class="lightbox_link" href="#login_lightbox"> Login Page </a> <br/>
            </form>
        </div>
