            <a class="mainbar_button" id="register_button" href="#register_lightbox"> Register </a>
            <a class="mainbar_button" id="login_button" href="#login_lightbox"> Login </a>

