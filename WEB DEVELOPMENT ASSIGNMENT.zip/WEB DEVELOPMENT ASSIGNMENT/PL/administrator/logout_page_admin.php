<div class="page_paragraph">
    You have been logged out as an administrator. <a href="index.php">Go back</a>
</div>

