                  <nav class="user_options"> 
                      <h4 class="panel_title"> Administrator Panel </h4>
                      <ul class="option_list">
                        <li> <a href="index.php?category=museum&page=Manage_Museums.php"> Manage Museums </a> </li>
                        <li> <a href="index.php?category=website_visitor&page=Manage_Visitors.php"> Manage Visitors </a> </li>
                        <li> <a href="index.php?category=administrator&page=Manage_Users.php"> Manage Users </a> </li>
                        <li> <a href="index.php?category=event&page=Manage_Events.php"> Manage Events </a> </li>
                        <li> <a href="index.php?category=room&page=Manage_Rooms.php"> Manage Rooms </a> </li>
                        <li> <a href="index.php?category=artist&page=Manage_Artists.php"> Manage Artists </a> </li>
                        <li> <a href="index.php?category=work&page=Manage_Works.php"> Manage Works </a> </li>
                        <li> <a href="index.php?category=ticket&page=Manage_Tickets.php"> Manage Tickets </a>  </li>
                        <li> <a href="index.php?category=artist_work&page=Manage_Works_Artists.php"> Manage Artist and Works </a>  </li>
                        <li> <a href="index.php?category=event_artist&page=Manage_Event_Artists.php"> Manage Events and Artists </a>  </li>
                      </ul>
                    </nav>
