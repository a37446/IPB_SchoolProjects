<?php
session_destroy();
include('logout_page.php');
?>