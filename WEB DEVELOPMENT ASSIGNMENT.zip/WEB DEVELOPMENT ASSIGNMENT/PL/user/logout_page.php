<div class="page_paragraph">
    You have been logged out. <a href="index.php">Go back</a>
</div>

