<?php if($_SESSION['outcome']==8) 
{echo '<h3 class="error_message"> Operation reported an error: Invalid Username or Login </h3>';}
else {include('user_info.php');} ?>


