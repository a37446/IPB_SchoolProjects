<h1 class="page_title"> [USER HOME PAGE] </h1> 
<div>
    <h3> PROFILE INFO </h3>
<div> Username: <?php echo $_SESSION['user_name']?> </div>
<div> Login: <?php echo $_SESSION['user_login']?></div>
<div> Mail: <?php echo $_SESSION['user_mail']?></div>
<div> User Description: <?php echo $_SESSION['user_description']?></div>
</div>