 <nav class="user_options"> 
                      <h4 class="panel_title"> User Profile </h4>
                      <ul class="option_list">
                        <li> <a href="index.php?category=user&page=Change_Username.php"> Change username </a> </li>
                        <li> <a href="index.php?category=user&page=Change_Password.php"> Change password </a> </li>
                        <li> <a href="index.php?category=user&page=Change_Description.php"> Change description </a> </li>
                      </ul>
                      <a id="ticket_history" class="side_link" href="index.php?category=ticket&page=Ticket_History.php"> Ticket History </a>
</nav>

